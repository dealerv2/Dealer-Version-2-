for pn in GIB_DEALS/gibdeal* ; do 
	fn=$( basename $pn ) ;
	echo  "Start $fn "; 
	./dop -gY -G $fn -i $pn -o GIB_CSV/$fn.csv -D1 ; 
done

