#/bin/bash
if [[ $# != 2 ]] ; then
   echo "Usage: $0 Start_Number Stop_Number "
   exit 1 ;
fi
d=1  #so we get an end of file confirmation
SRCDIR=GIB_DEALS
DSTDIR=GIB_CSV
ibeg=$( \printf "%03d" $1 )
iend=$( \printf "%03d" $2 )
echo "Start at $ibeg. Stop after $iend."
for i in $( seq $1 $2 ) ; do
   fi=$( \printf "%03d" $i )
   fn="gibdeals"$fi
   echo "Start processing $fn"

   # echo doing cmd now  from $SRCDIR/$fn to $DSTDIR/$fn.csv
   ./dop -D $d -gY -G $fn -i $SRCDIR/$fn -o $DSTDIR/$fn.csv
done
exit 0


