#!/bin/bash

# Author: JGM
#Version:
# 0.9 2018-05-13 -- first draft
# 1.0 2018-08-30 -- Added error checks for directories
#
set -o nounset   # force an exit if undefined variable Very Useful for Debugging....
# set -o verbose
# set -x
# set -n
#DATADIR="/home/greg19/Programming/Perl5/DOPGIB/GIB_DEALS"
DATADIR="/home/greg19/Programming/Perl5/DOPGIB/source"
PGMDIR="/home/greg19/Programming/Perl5/DOPGIB/source"
RPTDIR="/home/greg19/Programming/Perl5/DOPGIB/GIB_RPTS"

#
debug() {
echo "Arglist is"
echo "$@"
echo "cmd name is $0"
N=$( basename $0 )
echo "cmd base is $N"
echo "Number of args passed is: $# "
}
# debug
usage() {
   N=$( basename $0 ); echo "Usage: $N (directories etc are all hardcoded at this time)";
}
#

MIN_ARGS=2
N=$( basename $0 )

seg=0
cd $DATADIR
for fn in *.dat ; do
 bn=$( basename $fn )
 root=${bn%.*}
 rptn="${root}.csv"
 set="Seg"${seg}
 echo "Set $set Does File Number $seg [ $fn ] with Basename= ${bn} and Root=$root and Report $rptn"
 seg=$(( $seg + 1 ))
 $PGMDIR/dop -g -G "$set" -i "$fn" -o "$rptn" -D5
done
echo finished

