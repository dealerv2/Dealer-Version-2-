#!/usr/bin/perl
print "Enter DDS Hand: ";
while (<>) {
    $dds_hnd = $_ ;
    $dds_parsed = parse_DDSHand ($dds_hnd );
    print "$dds_parsed\n Another? ";
}

# A DDS deal has only one seat name, has dots between suits, and spaces between hands. Always exactly 16 chars per hand even with voids
# Ex: s .JT98765..765432 AKQJT9876543.2.. 2.43.AKQJT98765. .AKQ2.432.AKQJT98  so each hand has 3 dots always.
sub split_DDS_hand {
   my $hnd_str = shift;
   my ($snum, @suits) ;
   $hnd_str=~m/^(\w*)\.(\w*)\.(\w*)(\.(\w*))?/;
   print STDERR "split_DDS_hand:: $hnd_str :: [$1] ; [$2] ; [$3] ; [$4] ; [$5] { $Debug ge $req_dbg } \n" if  $Debug >= $req_dbg;
   @suits = ($1,$2,$3,$5) ;
   for ($snum=0; $snum < 4 ; $snum++ ) {
      if ($suits[$snum] eq "" ) { $suits[$snum] = "---" ; }
   }
   return (@suits);
} #end split_DDS_hand

# The DDShands string can be quite irregular if there are void suits. ".xxxxxx.xxxxxxx." for example if S and C are void.
sub cleanup_DDSHand {        # one hand 16 or so chars
   my $DDShand = shift ;
   local $req_dbg = $req_dbg + 1 ;
   chomp $DDShand ;

   print  STDERR "cleanup_DDShand::  Doing Cleanup for hand = $DDShand { $Debug >= $req_dbg }\n" if $Debug >= $req_dbg;
   if ($DDShand eq "") { return ("") ; }  # dont try to process null hand.
    $DDShand =~ s/10/T/g;                 # convert all occurrences of 10 to T.
    $_ = uc($DDShand);                    # convert all letters to upper case.

   if (~m/^(\s*[NESW][ :])(.+)/) { $_ = $2 ; } # just in case we were passed a seat designator
   if ( m/^\s*([0-9AKQJTakqjt .:]{13,})/ )    { $DDS_str = $1 ; }
   elsif ( m/^\s*#/) { next ; }  # Skip comments
   else { return -1 ; }  # silently ignore unknown lines
   print STDERR "parse_DDSHand:: [$DDS_str] {$Debug ge $req_dbg }\n" if $Debug >= $req_dbg;

   @suits = &split_DDS_hand($DDS_str) ;
   for ($i=0; $i<4; $i++ ) { if (length($suits[$i]) <= 0 ) { $suits[$i]="-" ; }  }
   $hand = join ',',@suits; #commas are needed for further processing..
      print STDERR "parse_DDSHand:: Hand[$hand] { $Debug ge $req_dbg} +1\n" if $Debug >= $req_dbg+1;
   &show_arr( "parse_DDSHand:: Suits: ",  \@suits) if $Debug >= $req_dbg+1;
   return $hand;
 }

