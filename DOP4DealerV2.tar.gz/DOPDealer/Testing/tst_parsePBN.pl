#!/usr/bin/perl
@s_name = ("Spades",  "Hearts" ,"Diams", "Clubs" );  # in GIB file Order.
foreach $h("e:AJ5.98.AKT85.T64 " , "w QT764.J.7.AQ9752" , "n .H.D", "S.H.D", "S.H..C", "...C", "S...C", "S...", "..D.C" ,".H..C" ,"S.H.." ,"S..D."  ) {

   print "Doing <$h>\n";
   $g = uc $h;
   if ( $g=~m/^(\s*[NESW][ :])(.+)/) { $g = $2 ; }
   printf "$g less $1 \n";
   $g=~m/^(\w*)\.(\w*)\.(\w*)(\.(\w*))?/;
   print "$g :: [$1] ; [$2] ; [$3] ; [$4] ; [$5] \n";
   @suits = ($1,$2,$3,$5) ;
   for ($i=0; $i < 4 ; $i++ ) {
      if ($suits[$i] eq "" ) { $suits[$i] = "---" ; }
      print "$s_name[$i] := $suits[$i] || ";
   }
   print "\n";
}
