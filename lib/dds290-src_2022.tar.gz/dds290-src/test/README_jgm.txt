This Dir does not contain the Haglund DOC file. Did I get this from Github?
