make dtest will succeed in building a working dtest with this libdds.a of size 4344006 which looks like Bo s original with all the threading in it
